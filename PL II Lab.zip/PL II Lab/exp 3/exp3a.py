string = input("Enter a string: ")

length = len(string)

print("Length of string:", length)
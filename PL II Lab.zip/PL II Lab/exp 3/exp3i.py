string = input("Enter a string: ")

words = string.split()

print("Split:", words)

joined = "-".join(words)

print("Joined with '-':", joined)
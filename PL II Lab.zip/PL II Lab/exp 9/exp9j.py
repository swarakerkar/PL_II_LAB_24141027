try:
    with open("sample.txt", "r") as file:
        print(file.read())
except FileNotFoundError:
    print("Error: File does not exist")
except PermissionError:
    print("Error: Permission denied")
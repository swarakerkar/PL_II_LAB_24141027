with open("sample.txt", "w") as file:
    file.write("Hello, this is a file.\n")
    file.write("Python file handling example.")

print("Data written successfully.")
with open("sample.txt", "r") as file:
    data = file.read()

print("File content:\n", data)
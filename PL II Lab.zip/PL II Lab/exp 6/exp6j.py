# Squares of numbers
squares = {x: x**2 for x in range(1, 6)}

print("Dictionary comprehension:", squares)
student = {"name": "Swara", "age": 20, "marks": 95}

# Delete using pop
student.pop("age")

# Delete using del
del student["marks"]

print("After deletion:", student)
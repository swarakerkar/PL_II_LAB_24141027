students = {
    "A": 85,
    "B": 92,
    "C": 88
}

top_student = max(students, key=students.get)

print("Top student:", top_student)
print("Marks:", students[top_student])
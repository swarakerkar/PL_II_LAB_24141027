d = {"b": 2, "a": 3, "c": 1}

# Sort by keys
print("Sorted by keys:", dict(sorted(d.items())))

# Sort by values
print("Sorted by values:", dict(sorted(d.items(), key=lambda x: x[1])))
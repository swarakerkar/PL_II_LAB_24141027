student = {
    "name": "Swara",
    "age": 20,
    "branch": "IT",
    "marks": 92
}

print("Student Details:", student)
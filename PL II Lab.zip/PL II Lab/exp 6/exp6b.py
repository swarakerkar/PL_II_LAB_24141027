student = {"name": "Swara", "age": 20, "marks": 92}

print("Keys:", student.keys())
print("Values:", student.values())
print("Items:", student.items())
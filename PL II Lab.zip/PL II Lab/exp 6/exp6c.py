student = {"name": "Swara", "age": 20}

# Add
student["marks"] = 95

# Update
student["age"] = 21

print("Updated dictionary:", student)
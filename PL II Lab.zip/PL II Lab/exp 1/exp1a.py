# Program to display personal biodata
name = "Swara"
age = 20
gender = "Female"
course = "B.Tech IT"
college = "XYZ University"

print("----- BIODATA -----")
print("Name:", name)
print("Age:", age)
print("Gender:", gender)
print("Course:", course)
print("College:", college)
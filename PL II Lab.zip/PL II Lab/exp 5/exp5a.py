t = (10, 20, 30, 40)

print("Tuple elements:", t)
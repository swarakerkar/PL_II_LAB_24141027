t = (1, 2, 3, 4)

lst = list(t)

print("Converted list:", lst)
t = (10, 20, 30, 40)

key = int(input("Enter element to check: "))

if key in t:
    print("Element found")
else:
    print("Element not found")
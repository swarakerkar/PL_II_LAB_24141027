s = {1, 2, 3, 4}

s.add(5)
s.remove(2)

print("Updated set:", s)
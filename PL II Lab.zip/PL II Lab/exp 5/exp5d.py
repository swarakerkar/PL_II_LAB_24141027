# Packing
t = 10, 20, 30

print("Packed tuple:", t)

# Unpacking
a, b, c = t

print("Unpacked values:", a, b, c)
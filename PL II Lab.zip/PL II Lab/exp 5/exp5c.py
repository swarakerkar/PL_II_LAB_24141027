t = tuple(map(int, input("Enter elements: ").split()))

print("Maximum:", max(t))
print("Minimum:", min(t))
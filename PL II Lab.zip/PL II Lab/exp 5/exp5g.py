s1 = {1, 2, 3, 4}
s2 = {3, 4, 5, 6}

print("Union:", s1 | s2)
print("Intersection:", s1 & s2)
print("Difference (s1 - s2):", s1 - s2)
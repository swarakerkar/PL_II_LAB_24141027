t = tuple(map(int, input("Enter elements: ").split()))

total = sum(t)
average = total / len(t)

print("Sum:", total)
print("Average:", average)
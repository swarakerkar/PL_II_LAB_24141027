t = tuple(map(int, input("Enter elements: ").split()))
key = int(input("Enter element to count: "))

count = t.count(key)

print("Occurrences:", count)
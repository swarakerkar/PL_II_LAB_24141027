class Student:
    college = "XYZ College"  # class variable

    def __init__(self, name):
        self.name = name      # instance variable

s1 = Student("Swara")
s2 = Student("Amit")

print(s1.name, s1.college)
print(s2.name, s2.college)
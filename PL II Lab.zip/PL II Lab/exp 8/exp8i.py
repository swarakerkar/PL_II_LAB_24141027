class Student:
    def __init__(self, name):
        self.__name = name  # private variable

    def get_name(self):
        return self.__name

s = Student("Swara")
print("Name:", s.get_name())
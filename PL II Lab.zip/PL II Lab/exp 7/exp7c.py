def operations(a, b):
    return a + b, a - b

sum_val, diff_val = operations(10, 5)

print("Sum:", sum_val)
print("Difference:", diff_val)
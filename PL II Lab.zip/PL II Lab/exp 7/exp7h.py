lst = [1, 2, 3, 4, 5]

print("Length:", len(lst))
print("Maximum:", max(lst))
print("Minimum:", min(lst))
print("Sum:", sum(lst))
x = 10  # global

def test():
    x = 5  # local
    print("Inside function:", x)

test()
print("Outside function:", x)
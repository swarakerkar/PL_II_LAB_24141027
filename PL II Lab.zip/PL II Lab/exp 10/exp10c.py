import tkinter as tk

def submit():
    print("Name:", name.get())
    print("Age:", age.get())

root = tk.Tk()
root.title("Student Form")

tk.Label(root, text="Name").grid(row=0, column=0)
name = tk.Entry(root)
name.grid(row=0, column=1)

tk.Label(root, text="Age").grid(row=1, column=0)
age = tk.Entry(root)
age.grid(row=1, column=1)

tk.Button(root, text="Submit", command=submit).grid(row=2, column=1)

root.mainloop()
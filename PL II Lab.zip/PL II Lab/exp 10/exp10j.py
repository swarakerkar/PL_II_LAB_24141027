import matplotlib.pyplot as plt

x = []
y = []

with open("data.txt", "r") as file:
    for line in file:
        a, b = map(int, line.split())
        x.append(a)
        y.append(b)

plt.plot(x, y)
plt.title("Plot from File Data")
plt.xlabel("X")
plt.ylabel("Y")
plt.show()
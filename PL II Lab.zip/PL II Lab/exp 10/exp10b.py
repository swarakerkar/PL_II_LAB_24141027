import tkinter as tk

def calculate():
    try:
        result = eval(entry.get())
        output.config(text="Result: " + str(result))
    except:
        output.config(text="Error")

root = tk.Tk()
root.title("Calculator")

entry = tk.Entry(root)
entry.pack()

btn = tk.Button(root, text="Calculate", command=calculate)
btn.pack()

output = tk.Label(root, text="")
output.pack()

root.mainloop()
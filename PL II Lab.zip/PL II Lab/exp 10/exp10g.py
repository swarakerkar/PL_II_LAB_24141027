import matplotlib.pyplot as plt

labels = ["A", "B", "C"]
sizes = [40, 35, 25]

plt.pie(sizes, labels=labels, autopct="%1.1f%%")
plt.title("Pie Chart")
plt.show()
lst = list(map(int, input("Enter elements: ").split()))

even = 0
odd = 0

for num in lst:
    if num % 2 == 0:
        even += 1
    else:
        odd += 1

print("Even count:", even)
print("Odd count:", odd)
lst = list(map(int, input("Enter elements: ").split()))

print("Maximum:", max(lst))
print("Minimum:", min(lst))
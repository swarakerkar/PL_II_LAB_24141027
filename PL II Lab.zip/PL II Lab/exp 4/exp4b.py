lst = list(map(int, input("Enter elements: ").split()))

total = sum(lst)
average = total / len(lst)

print("Sum:", total)
print("Average:", average)
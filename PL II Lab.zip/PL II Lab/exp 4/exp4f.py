lst = list(map(int, input("Enter elements: ").split()))
key = int(input("Enter element to search: "))

if key in lst:
    print("Element found at index:", lst.index(key))
else:
    print("Element not found")
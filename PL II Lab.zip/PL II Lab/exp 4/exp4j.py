lst = list(map(int, input("Enter elements: ").split()))

print("Original list:", lst)
print("First 3 elements:", lst[:3])
print("Last 3 elements:", lst[-3:])
print("Reversed list:", lst[::-1])
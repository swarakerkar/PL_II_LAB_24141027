lst = list(map(int, input("Enter elements: ").split()))

lst.sort()

print("Sorted list:", lst)
lst = list(map(int, input("Enter elements: ").split()))

unique_lst = list(set(lst))

print("List without duplicates:", unique_lst)

# but this way, the order is not preserved

unique_lst = []
for item in lst:
    if item not in unique_lst:
        unique_lst.append(item)

# this preserves the order
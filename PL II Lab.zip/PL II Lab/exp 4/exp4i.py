lst = list(map(int, input("Enter elements: ").split()))

unique_lst = list(set(lst))

if len(unique_lst) < 2:
    print("No second largest element")
else:
    unique_lst.sort()
    print("Second largest:", unique_lst[-2])
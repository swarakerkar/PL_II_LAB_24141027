# 💰 Fynance - Personal Finance Manager

A full-stack web-based personal finance manager built with **Python (Flask)** backend and a polished dark-themed frontend.

## Features
- **Dashboard** - Monthly income/expense summary, 6-month trend chart, category donut chart, recent transactions
- **Transactions** - Add, filter, delete income & expense entries with category tagging
- **Budgets** - Set monthly spending limits per category with visual progress bars (turns amber/red when nearing/exceeding)
- **Savings Goals** - Create and track financial goals with progress bars and deadlines

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Backend | Python 3 + Flask + Flask-CORS |
| Storage | JSON file (data.json) |
| Frontend | Vanilla HTML/CSS/JS (no framework) |
| Fonts | DM Serif Display, DM Mono, Sora (Google Fonts) |

## Project Structure
```
finance-manager/
├── app.py          ← Flask REST API (all routes)
├── data.json       ← Auto-created data store
├── seed_data.py    ← Optional: populate with demo data
├── requirements.txt
└── static/
    └── index.html  ← Complete SPA frontend
```

## Setup & Run

### 1. Install dependencies
```bash
pip install flask flask-cors
```

### 2. (Optional) Load demo data
```bash
python seed_data.py
```

### 3. Start the server
```bash
python app.py
```

### 4. Open in browser
```
http://localhost:5000
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/transactions` | List transactions (filter: month, category) |
| POST | `/api/transactions` | Add transaction |
| PUT | `/api/transactions/<id>` | Update transaction |
| DELETE | `/api/transactions/<id>` | Delete transaction |
| GET | `/api/summary` | Dashboard summary + trend |
| GET | `/api/budgets` | List budgets with spent amounts |
| POST | `/api/budgets` | Add/update budget |
| DELETE | `/api/budgets/<id>` | Remove budget |
| GET | `/api/goals` | List savings goals |
| POST | `/api/goals` | Create goal |
| PUT | `/api/goals/<id>` | Update goal |
| DELETE | `/api/goals/<id>` | Delete goal |

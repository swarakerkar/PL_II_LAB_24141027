from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import os
import uuid
from datetime import datetime, date
import calendar

app = Flask(__name__, static_folder='static')
CORS(app)

DATA_FILE = 'data.json'
 
def load_data():
    if not os.path.exists(DATA_FILE):
        default_data = {
            "transactions": [],
            "budgets": [],
            "savings_goals": []
        }
        save_data(default_data)
        return default_data
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

# ── Transactions ─────────────────────────────────────────────────────────────

@app.route('/api/transactions', methods=['GET'])
def get_transactions():
    data = load_data()
    txns = data['transactions']
    month = request.args.get('month')   # "YYYY-MM"
    category = request.args.get('category')
    if month:
        txns = [t for t in txns if t['date'].startswith(month)]
    if category:
        txns = [t for t in txns if t['category'] == category]
    txns.sort(key=lambda x: x['date'], reverse=True)
    return jsonify(txns)

@app.route('/api/transactions', methods=['POST'])
def add_transaction():
    data = load_data()
    body = request.json

    txn_type = body['type']
    category = body['category']
    amount = float(body['amount'])
    txn_date = body.get('date', date.today().isoformat())
    month = txn_date[:7]   # "YYYY-MM"

    # 🚨 STEP 1: Budget check ONLY for expenses
    if txn_type == 'expense':
        # Find budget for this category
        budget = next((b for b in data['budgets'] if b['category'] == category), None)

        if budget:
            # Calculate current spent in this month
            spent = sum(
                t['amount']
                for t in data['transactions']
                if t['type'] == 'expense'
                and t['category'] == category
                and t['date'].startswith(month)
            )

            # 🚨 STEP 2: Check limit
            if spent + amount > budget['limit']:
                return jsonify({
                    "error": "Budget exceeded",
                    "category": category,
                    "limit": budget['limit'],
                    "spent": spent,
                    "attempted": amount
                }), 400

    # ✅ If OK → add transaction
    txn = {
        "id": str(uuid.uuid4()),
        "date": txn_date,
        "description": body['description'],
        "amount": amount,
        "type": txn_type,
        "category": category,
        "notes": body.get('notes', '')
    }

    data['transactions'].append(txn)
    save_data(data)
    return jsonify(txn), 201

@app.route('/api/transactions/<txn_id>', methods=['DELETE'])
def delete_transaction(txn_id):
    data = load_data()
    data['transactions'] = [t for t in data['transactions'] if t['id'] != txn_id]
    save_data(data)
    return jsonify({"deleted": txn_id})

@app.route('/api/transactions/<txn_id>', methods=['PUT'])
def update_transaction(txn_id):
    data = load_data()
    body = request.json
    for t in data['transactions']:
        if t['id'] == txn_id:
            t.update({k: v for k, v in body.items() if k != 'id'})
            if 'amount' in t:
                t['amount'] = float(t['amount'])
            save_data(data)
            return jsonify(t)
    return jsonify({"error": "Not found"}), 404

# ── Summary ───────────────────────────────────────────────────────────────────

@app.route('/api/summary', methods=['GET'])
def get_summary():
    data = load_data()
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    txns = [t for t in data['transactions'] if t['date'].startswith(month)]

    income = sum(t['amount'] for t in txns if t['type'] == 'income')
    expenses = sum(t['amount'] for t in txns if t['type'] == 'expense')

    # Category breakdown
    cat_breakdown = {}
    for t in txns:
        if t['type'] == 'expense':
            cat_breakdown[t['category']] = cat_breakdown.get(t['category'], 0) + t['amount']

    # Last 6 months trend
    trend = []
    today = date.today()
    for i in range(5, -1, -1):
        m = today.month - i
        y = today.year
        while m <= 0:
            m += 12
            y -= 1
        key = f"{y}-{m:02d}"
        mo_txns = [t for t in data['transactions'] if t['date'].startswith(key)]
        trend.append({
            "month": key,
            "label": calendar.month_abbr[m],
            "income": sum(t['amount'] for t in mo_txns if t['type'] == 'income'),
            "expenses": sum(t['amount'] for t in mo_txns if t['type'] == 'expense')
        })

    return jsonify({
        "month": month,
        "income": income,
        "expenses": expenses,
        "balance": income - expenses,
        "category_breakdown": cat_breakdown,
        "trend": trend
    })

# ── Budgets ───────────────────────────────────────────────────────────────────

@app.route('/api/budgets', methods=['GET'])
def get_budgets():
    data = load_data()
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    txns = [t for t in data['transactions'] if t['date'].startswith(month) and t['type'] == 'expense']
    spent_by_cat = {}
    for t in txns:
        spent_by_cat[t['category']] = spent_by_cat.get(t['category'], 0) + t['amount']

    result = []
    for b in data['budgets']:
        result.append({**b, "spent": spent_by_cat.get(b['category'], 0)})
    return jsonify(result)

@app.route('/api/budgets', methods=['POST'])
def add_budget():
    data = load_data()
    body = request.json
    # upsert by category
    for b in data['budgets']:
        if b['category'] == body['category']:
            b['limit'] = float(body['limit'])
            save_data(data)
            return jsonify(b)
    budget = {"id": str(uuid.uuid4()), "category": body['category'], "limit": float(body['limit'])}
    data['budgets'].append(budget)
    save_data(data)
    return jsonify(budget), 201

@app.route('/api/budgets/<budget_id>', methods=['DELETE'])
def delete_budget(budget_id):
    data = load_data()
    data['budgets'] = [b for b in data['budgets'] if b['id'] != budget_id]
    save_data(data)
    return jsonify({"deleted": budget_id})

# ── Savings Goals ─────────────────────────────────────────────────────────────

@app.route('/api/goals', methods=['GET'])
def get_goals():
    return jsonify(load_data()['savings_goals'])

@app.route('/api/goals', methods=['POST'])
def add_goal():
    data = load_data()
    body = request.json
    goal = {
        "id": str(uuid.uuid4()),
        "name": body['name'],
        "target": float(body['target']),
        "saved": float(body.get('saved', 0)),
        "deadline": body.get('deadline', ''),
        "emoji": body.get('emoji', '🎯')
    }
    data['savings_goals'].append(goal)
    save_data(data)
    return jsonify(goal), 201

@app.route('/api/goals/<goal_id>', methods=['PUT'])
def update_goal(goal_id):
    data = load_data()
    body = request.json
    for g in data['savings_goals']:
        if g['id'] == goal_id:
            g.update({k: v for k, v in body.items() if k != 'id'})
            for field in ['target', 'saved']:
                if field in g:
                    g[field] = float(g[field])
            save_data(data)
            return jsonify(g)
    return jsonify({"error": "Not found"}), 404

@app.route('/api/goals/<goal_id>', methods=['DELETE'])
def delete_goal(goal_id):
    data = load_data()
    data['savings_goals'] = [g for g in data['savings_goals'] if g['id'] != goal_id]
    save_data(data)
    return jsonify({"deleted": goal_id})

# ── Serve frontend ────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    os.makedirs('static', exist_ok=True)
    app.run(debug=True, port=5000)

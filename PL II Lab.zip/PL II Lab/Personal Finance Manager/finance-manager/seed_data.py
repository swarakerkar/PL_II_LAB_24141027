"""
seed_data.py - Populate Fynance with realistic demo data
Run once: python seed_data.py
"""
import json, os, uuid
from datetime import date, timedelta
import random

DATA_FILE = 'data.json'

transactions = []
today = date.today()

# Helper
def txn(desc, amount, t, cat, days_ago, notes=''):
    d = (today - timedelta(days=days_ago)).isoformat()
    return {"id": str(uuid.uuid4()), "date": d, "description": desc,
            "amount": amount, "type": t, "category": cat, "notes": notes}

# This month
transactions += [
    txn("Monthly Salary", 55000, "income", "Salary", 2),
    txn("Freelance Project - Logo Design", 8000, "income", "Freelance", 5),
    txn("Zomato - Pizza & Pasta", 620, "expense", "Food & Dining", 1),
    txn("Swiggy Grocery", 1840, "expense", "Food & Dining", 3),
    txn("Ola Cab to Airport", 480, "expense", "Transport", 4),
    txn("Monthly Bus Pass", 650, "expense", "Transport", 7),
    txn("Amazon - Books", 990, "expense", "Shopping", 5),
    txn("Myntra - T-shirts × 3", 1350, "expense", "Shopping", 8),
    txn("Netflix + Spotify", 499, "expense", "Entertainment", 6),
    txn("Movie Tickets × 2", 380, "expense", "Entertainment", 3),
    txn("Gym Membership", 1200, "expense", "Health & Fitness", 2),
    txn("Electricity Bill", 1840, "expense", "Housing & Utilities", 10),
    txn("Udemy Course - React", 499, "expense", "Education", 9),
]

# Last month
lm = 32
transactions += [
    txn("Monthly Salary", 55000, "income", "Salary", lm+1),
    txn("Freelance API Work", 12000, "income", "Freelance", lm+10),
    txn("Restaurant Dinner", 1200, "expense", "Food & Dining", lm+3),
    txn("Petrol", 2200, "expense", "Transport", lm+5),
    txn("Flipkart - Headphones", 2499, "expense", "Shopping", lm+7),
    txn("Water & Internet Bill", 1100, "expense", "Housing & Utilities", lm+12),
    txn("Pharmacy", 560, "expense", "Health & Fitness", lm+15),
    txn("College Fee", 8000, "expense", "Education", lm+2),
    txn("Weekend Trip Expenses", 3400, "expense", "Entertainment", lm+20),
]

# 2 months ago
tm = 65
transactions += [
    txn("Monthly Salary", 55000, "income", "Salary", tm+1),
    txn("Consulting Work", 5000, "income", "Freelance", tm+14),
    txn("Groceries", 2100, "expense", "Food & Dining", tm+4),
    txn("Auto Rickshaw", 320, "expense", "Transport", tm+6),
    txn("Clothing", 1800, "expense", "Shopping", tm+9),
    txn("Rent", 12000, "expense", "Housing & Utilities", tm+1),
    txn("Doctor Visit", 800, "expense", "Health & Fitness", tm+18),
]

budgets = [
    {"id": str(uuid.uuid4()), "category": "Food & Dining", "limit": 5000},
    {"id": str(uuid.uuid4()), "category": "Transport", "limit": 2000},
    {"id": str(uuid.uuid4()), "category": "Shopping", "limit": 3000},
    {"id": str(uuid.uuid4()), "category": "Entertainment", "limit": 1500},
    {"id": str(uuid.uuid4()), "category": "Health & Fitness", "limit": 2000},
]

goals = [
    {"id": str(uuid.uuid4()), "name": "Emergency Fund", "target": 100000, "saved": 42000, "deadline": "2025-12-31", "emoji": "🏦"},
    {"id": str(uuid.uuid4()), "name": "New Laptop", "target": 80000, "saved": 23500, "deadline": "2025-08-01", "emoji": "💻"},
    {"id": str(uuid.uuid4()), "name": "Goa Trip", "target": 25000, "saved": 18000, "deadline": "2025-06-01", "emoji": "🏖️"},
    {"id": str(uuid.uuid4()), "name": "DSLR Camera", "target": 55000, "saved": 8000, "deadline": "2026-01-01", "emoji": "📸"},
]

data = {"transactions": transactions, "budgets": budgets, "savings_goals": goals}
with open(DATA_FILE, 'w') as f:
    json.dump(data, f, indent=2)

print(f" Seeded {len(transactions)} transactions, {len(budgets)} budgets, {len(goals)} goals.")
